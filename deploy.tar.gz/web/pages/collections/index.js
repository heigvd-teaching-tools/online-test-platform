import PageList from '../../components/collections/pages/PageList'

const Exams = () => <PageList />

export default Exams
