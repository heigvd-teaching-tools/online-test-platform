import PageUpdate from '../../../../components/questions/pages/PageUpdate'

const UpdateExam = () => <PageUpdate />

export default UpdateExam
