import PageCompose from '../../../components/collections/pages/PageCompose'

const ComposeCollection = () => <PageCompose />

export default ComposeCollection
