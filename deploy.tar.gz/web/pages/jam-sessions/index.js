import PageList from '../../components/jam-sessions/pages/PageList'

const JamSessions = () => <PageList />

export default JamSessions
