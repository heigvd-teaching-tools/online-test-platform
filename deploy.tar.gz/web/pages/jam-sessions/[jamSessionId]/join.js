import PageJoin from '../../../components/jam-sessions/pages/student/PageJoin'

const JoinJamSession = () => <PageJoin />

export default JoinJamSession
