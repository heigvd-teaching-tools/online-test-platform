import PageAnalytics from '../../../components/jam-sessions/pages/PageAnalytics'

const JamSessionAnalytics = () => <PageAnalytics />

export default JamSessionAnalytics
