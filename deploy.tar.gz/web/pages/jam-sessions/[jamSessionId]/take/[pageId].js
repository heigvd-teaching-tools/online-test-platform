import PageTakeJam from '../../../../components/jam-sessions/pages/student/PageTakeJam'

const TakeJamSession = () => <PageTakeJam />

export default TakeJamSession
