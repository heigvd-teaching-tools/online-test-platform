import PageConsult from '../../../../components/jam-sessions/pages/student/PageConsult'

const ConsultJamSession = () => <PageConsult />

export default ConsultJamSession
