import PageGrading from '../../../../components/jam-sessions/pages/PageGrading'

const Grading = () => <PageGrading />

export default Grading
