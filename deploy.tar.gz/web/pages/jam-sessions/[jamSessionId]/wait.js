import PageWaiting from '../../../components/jam-sessions/pages/student/PageWaiting'

const WaitJamSession = () => <PageWaiting />

export default WaitJamSession
