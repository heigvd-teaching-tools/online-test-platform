import PageDraft from '../../../../components/jam-sessions/pages/PageDraft'

const Draft = () => <PageDraft />

export default Draft
