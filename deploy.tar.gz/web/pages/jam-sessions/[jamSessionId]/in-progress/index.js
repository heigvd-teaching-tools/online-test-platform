import PageInProgress from '../../../../components/jam-sessions/pages/PageInProgress'

const InProgress = () => <PageInProgress />

export default InProgress
