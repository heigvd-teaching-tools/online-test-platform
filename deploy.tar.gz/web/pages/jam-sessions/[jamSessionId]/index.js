import PageDispatch from '../../../components/jam-sessions/pages/student/PageDispatch'

const StudentDispatch = () => <PageDispatch />

export default StudentDispatch
