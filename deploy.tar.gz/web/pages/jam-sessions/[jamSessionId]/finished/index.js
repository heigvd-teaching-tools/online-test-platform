import PageFinished from '../../../../components/jam-sessions/pages/PageFinished'

const Finished = () => <PageFinished />

export default Finished
