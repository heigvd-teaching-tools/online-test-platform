import PageDraft from '../../components/jam-sessions/pages/PageDraft'

const NewJamSession = () => <PageDraft />

export default NewJamSession
