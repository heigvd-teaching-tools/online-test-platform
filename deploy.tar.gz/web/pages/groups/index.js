import PageList from '../../components/groups/pages/PageList'

const Exams = () => <PageList />

export default Exams
