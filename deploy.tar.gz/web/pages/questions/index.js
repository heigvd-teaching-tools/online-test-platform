import PageList from '../../components/questions/pages/PageList'
const Exams = () => <PageList />
export default Exams
