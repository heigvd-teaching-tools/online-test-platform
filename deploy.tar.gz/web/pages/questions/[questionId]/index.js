import PageUpdate from '../../../components/questions/pages/PageUpdate'

const UpdateQuestion = () => <PageUpdate />

export default UpdateQuestion
