const ConsoleLog = (props) => {
    console.log("ConsoleLog", props);
    return false;
}

export default ConsoleLog;
