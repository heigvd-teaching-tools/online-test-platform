const TabPanel = ({ children, value, index }) => value === index && children
export default TabPanel
