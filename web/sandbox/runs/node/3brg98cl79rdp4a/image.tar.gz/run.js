
    var Sum = (a, b) => a * b;
    console.log(Sum(12, 34));
