
    var Sum = (a, b) => a * b;
    console.log(Sum(111, 99));
